/**************************************************************/
/* VirtualMem.exe: Small tool for playing with Virtual Memory.*/
/*      With the user input parameters, you can specify       */
/*      address starting, number and size of region. It will  */
/*      be also possible to set number and size block.        */
/*      Finally, to force RAM using, you can write n bytes in */
/*      each commited blocks.                                 */
/*                                                            */
/* This tool is developped for the 50-1337 eMagazine 1,       */
/* "Balade avec la m�moire virtuelle" paper.                  */
/*                                                            */
/* 12/11/2009 by Homeostasie (homeostasie at live dot fr)     */
/**************************************************************/

#include <windows.h>
#include <tchar.h>
#include <stdio.h>
#include <stdlib.h>
#include <conio.h>

#define BLOCKLIMIT 32768    // Max Number of block to ask
#define HELP    "Help menu, below list of available arguments:\n" \
                "---------------------------------------------\n" \
                "--startaddr:  Starting HEXADECIMAL address of region to reserve (by default NULL)\n" \
                "--regionnum:  Number of region to reserve (by default 1)\n" \
                "--regionsize: Size of region to reserve (by default frame granularity, 64k on Win32)\n" \
                "--blocknum:   Number of block to commit (by default 0)\n" \
                "--blocksize:  Size of block to commit (by default page size, 4k on Win32\n" \
                "--write:      Write n bytes into each commited memory block to force physical memory usage\n"

#define USED_PARAMETERS "Start Address: %p\n" \
                        "Region Number: %lu\n" \
                        "RegionSize:    %lu bytes\n" \
                        "Page Number:   %lu\n" \
                        "Commited size: %lu bytes\n"

void myGetLastError(void)
{
    LPVOID lpMsgBuf;
    FormatMessage(
        FORMAT_MESSAGE_ALLOCATE_BUFFER |
        FORMAT_MESSAGE_FROM_SYSTEM |
        FORMAT_MESSAGE_IGNORE_INSERTS,
        NULL,
        GetLastError(),
        0, // Default language
        (LPTSTR) &lpMsgBuf,
        0,
        NULL
    );

    printf("%s\n", (char*)lpMsgBuf);

    LocalFree( lpMsgBuf );
}


int main(int argc, char *argv[])
{
	LPVOID lpvBase, lpvNext, lpvResult; // Base address of memory
	LPTSTR lpTabPage[BLOCKLIMIT];       // Address array of virtual memory page
	BOOL bSuccess;                      // Flag
	DWORD i,j;                          // Generic counters
	LPVOID lpvStartAddress,lpvStartBase;// Starting address of region
    DWORD dwRegionNumber;               // Region number to rerserve/allocate
    DWORD dwSizeToAllocate;             // Virtual memory size to allocate by Block
    DWORD dwBlockNum;                   // Number of commited blocks
    DWORD dwPageSize;                   // Page size value
    DWORD dwNumToWrite;                 // Number of byte to write for each blocks
    char *strToWrite = NULL;            // String to write
	SYSTEM_INFO sSysInfo;               // Useful information about the system

	// Initialize local variables
	GetSystemInfo(&sSysInfo);
	dwPageSize = sSysInfo.dwPageSize;
	dwSizeToAllocate = sSysInfo.dwAllocationGranularity;
	dwRegionNumber = 1;
	dwBlockNum = 0;
	dwNumToWrite = 0;
	lpvStartBase = lpvStartAddress = NULL;

    system("CLS");
    printf ("-------------------------------------------------------------\n");
    printf ("*-----------------------------------------------------------*\n");
	printf ("*                                                           *\n");
	printf ("*       Walking with the Virtual Memory by Homeostasie      *\n");
	printf ("*                                                           *\n");
	printf ("*     (501337 eZine1 for Attack Vector & Europa|Security)   *\n");
	printf ("*                                                           *\n");
	printf ("*                                                           *\n");
	printf ("*-----------------------------------------------------------*\n");
	printf ("-------------------------------------------------------------\n\n\n");

	if(argc > 13)
	{
        printf("Invalid number of arguments.\n--help to get information.\n");
        return EXIT_FAILURE;
	}
	else
	{
        for(i = 1 ; i < argc; i++)
        {
            if(strcmp(argv[i],"--startaddr")==0){
                i++;
                lpvStartBase = (LPVOID)strtoul(argv[i], NULL, 16);
            }
            else if(strcmp(argv[i],"--regionnum")==0){
                i++;
                dwRegionNumber = strtoul(argv[i], NULL, 10);
            }
            else if(strcmp(argv[i],"--regionsize")==0){
                i++;
                dwSizeToAllocate = strtoul(argv[i], NULL, 10);
            }
            else if(strcmp(argv[i],"--blocknum")==0){
                i++;
                dwBlockNum = strtoul(argv[i], NULL, 10);
            }
            else if(strcmp(argv[i],"--blocksize")==0){
                i++;
                dwPageSize = strtoul(argv[i], NULL, 10);
            }
            else if(strcmp(argv[i],"--write")==0){
                i++;
                dwNumToWrite = strtoul(argv[i], NULL, 10);
                if(dwNumToWrite) {
                    strToWrite = malloc(dwNumToWrite);
                    if(strToWrite == NULL){
                        printf("\t-> malloc FAILED: ");
                        myGetLastError();
                        return EXIT_FAILURE;
                    }
                    else{
                        DWORD k = 0;
                        for(k = 0; k < dwNumToWrite; k++) {strToWrite[k] = 'a';}
                    }
                }
            }
            else{
                printf("%s\n", HELP);
                return EXIT_FAILURE;
            }
        }
	}

    printf ("Used Parameters for this test\n");
	printf ("----------------------------------\n");
	printf (USED_PARAMETERS, lpvStartBase, dwRegionNumber, dwSizeToAllocate, dwBlockNum, dwPageSize);

	printf ("\nInformation about Virtual Memory\n");
	printf ("----------------------------------\n");
	printf ("Granularity for the starting address at which virtual memory can be allocated: %lu (0x%x).\n",
                                                            sSysInfo.dwAllocationGranularity,
                                                            sSysInfo.dwAllocationGranularity);
	printf ("Computer page size: %lu (0x%x).\n", sSysInfo.dwPageSize, sSysInfo.dwPageSize);
    printf ("Lowest memory address accessible: %lu (0x%x).\n", sSysInfo.lpMinimumApplicationAddress,
                                                            sSysInfo.lpMinimumApplicationAddress);
	printf ("Highest memory address accessible: %lu (0x%x).\n", sSysInfo.lpMaximumApplicationAddress,
                                                            sSysInfo.lpMaximumApplicationAddress);

    printf("\n/!\\ Please, press key to reserve and commit virtual memory...\n"); _getch();

	printf ("\nReserve and commit Virtual Memory\n");
	printf ("-----------------------------------\n");
	for(i = 0; i < dwRegionNumber; i++)
	{
        if(lpvStartBase != NULL)
            lpvStartAddress = lpvStartBase + i*(dwSizeToAllocate);

        // Reserve pages in the virtual address space of the process.
        lpvBase = VirtualAlloc(
                         lpvStartAddress,      // System by default or user selects address
                         dwSizeToAllocate,     // Size of allocation
                         MEM_RESERVE,          // Allocate reserved pages
                         PAGE_NOACCESS);       // Protection = no access
        if (lpvBase == NULL )
        {
            printf("(%05lu) VirtualAlloc reserve failed: ", i);
            myGetLastError();
        }
        else
        {
            lpTabPage[i] = lpvBase;
            printf("(%05lu) VirtualAlloc succeed to reserve a block. (Virtual Base Address of Block = 0x%p)\n", i, lpvBase);

            for(j = 0; j < dwBlockNum; j++)
            {
                lpvNext = lpvBase + j*dwPageSize;
                lpvResult = VirtualAlloc(
                                 (LPVOID) lpvNext,  // Next memory location to commit
                                 dwPageSize,        // Page size, in bytes
                                 MEM_COMMIT,        // Allocate a committed page
                                 PAGE_READWRITE);   // Read/write access
                if (lpvResult == NULL )
                {
                    printf("\t-> (%02lu) VirtualAlloc commit FAILED: ", j);
                    myGetLastError();
                }
                else
                {
                    printf("\t-> (%02lu) VirtualAlloc succeed to commit a size of %lu bytes.(Virtual Base Address of Page = 0x%p)\n", j, dwPageSize,lpvResult);
                    if(dwNumToWrite){
                        if(memcpy(lpvNext, strToWrite, dwNumToWrite) != lpvNext){
                            printf("\t-> memcpy FAILED: ");
                            myGetLastError();
                        }
                    }
                }
            }
        }
	}

    printf("\n/!\\ Please, press key to release blocks...\n"); _getch();

	printf ("\nRelease blocks of Virtual Memory page\n");
	printf ("---------------------------------------\n");
	// Release the block of pages when you are finished using them.
	for(i = 0; i < dwRegionNumber; i++)
	{
        lpvBase = lpTabPage[i];
        if(lpvBase != NULL)
        {
            bSuccess = VirtualFree(
                               lpvBase,       // Base address of block
                               0,             // Bytes of committed pages
                               MEM_RELEASE);  // Decommit the pages
            printf ("Release (0x%p) %s", lpTabPage[i], bSuccess ? "succeeded.\n" : "failed: " );
            if(bSuccess == FALSE) myGetLastError();
        }
	}

    printf("\n/!\\ Please, press key to exit...\n"); _getch();
    if(strToWrite != NULL) free(strToWrite);

    return EXIT_SUCCESS;
}
